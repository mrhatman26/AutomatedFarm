How to run:
To run, ensure that the file "paths.txt" is in the same directory as the "AutoFarm (Run).jar" file.
Then, simply run "AutoFarm (Run).jar".
Please note that this might not run on some systems as it requires OpenGL.

You can find this project on GitHub at: https://github.com/mrhatman26/AutomatedFarm